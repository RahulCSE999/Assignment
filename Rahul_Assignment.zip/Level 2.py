#Level 2
#Choosing the teacher and a student pair. Generate the certificate
"""Create a new view that allows you to choose a teacher and student pair and generate a certificate.
You can create a new view in your app's views.py (e.g., myapp/views.py) as follows:"""

from django.shortcuts import render
from django.http import HttpResponse
from .models import Student, Teacher, StudentTeacher

def generate_certificate(request):
    if request.method == 'POST':
        student_id = request.POST['student_id']
        teacher_id = request.POST['teacher_id']
        
        student = Student.objects.get(pk=student_id)
        teacher = Teacher.objects.get(pk=teacher_id)
        
        # Create and render the certificate
        context = {'student': student, 'teacher': teacher}
        return render(request, 'certificate.html', context)
    
    students = Student.objects.all()
    teachers = Teacher.objects.all()
    
    context = {'students': students, 'teachers': teachers}
    return render(request, 'generate_certificate.html', context)

"""Create templates for the views. You'll need two templates:
one for choosing the teacher and student pair (generate_certificate.html) and another for rendering the certificate (certificate.html).
Create these templates in your app's templates directory.generate_certificate.html:"""

<form method="post">
    {% csrf_token %}
    <label for="student_id">Select a Student:</label>
    <select name="student_id" id="student_id">
        {% for student in students %}
            <option value="{{ student.id }}">{{ student.name }}</option>
        {% endfor %}
    </select>

    <label for="teacher_id">Select a Teacher:</label>
    <select name="teacher_id" id="teacher_id">
        {% for teacher in teachers %}
            <option value="{{ teacher.id }}">{{ teacher.name }}</option>
        {% endfor %}
    </select>

    <button type="submit">Generate Certificate</button>
</form>

#certificate.html
"""<!DOCTYPE html>
<html>
<head>
    <title>Certificate</title>
</head>
<body>
    <h1>Certificate</h1>
    <p>This is to certify that {{ student.name }} has successfully studied under the guidance of {{ teacher.name }}.</p>
</body>
</html>"""

#Create URLs for the new view in your app's urls.py (e.g., myapp/urls.py):
from django.urls import path
from . import views

urlpatterns = [
    # Your existing views
    # ...
    path('generate_certificate/', views.generate_certificate, name='generate_certificate'),
]
"""Finally, make sure you have the appropriate URLs configured in your project's urls.py as shown in the previous answer.
Now, when you visit the /generate_certificate/ URL, you will see a form where you can choose a teacher and a student.
When you submit the form, it will generate and display the certificate based on the selected teacher and student pair.
you can further customize the certificate template to meet your specific needs."""
