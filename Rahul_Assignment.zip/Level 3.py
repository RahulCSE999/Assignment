#level 3 -Verify the certificate using the JWT token
#Install the PyJWT library if you haven't already. You can install it using pip:
pip install PyJWT

"""Create a function in your Django app to generate JWT tokens for certificates.
You can do this by using a secret key and encoding the data you want to include in the token.
For example, you might want to include information about the student, teacher, and certificate expiration date."""

import jwt
from datetime import datetime, timedelta

def generate_certificate_token(student_id, teacher_id):
    # Create a payload with the student and teacher IDs and an expiration time
    payload = {
        'student_id': student_id,
        'teacher_id': teacher_id,
        'exp': datetime.utcnow() + timedelta(days=30)  # Token expiration date
    }

    # Encode the payload with your secret key
    token = jwt.encode(payload, 'your_secret_key', algorithm='HS256')

    return token

#Replace 'your_secret_key' with a secure secret key.

# Next, create a view in your Django app to verify certificates using the JWT token. In this view, you'll decode the token and validate it.

import jwt
from datetime import datetime

from django.http import HttpResponse, JsonResponse
from .models import Student, Teacher

def verify_certificate(request, token):
    try:
        # Decode the token with your secret key
        payload = jwt.decode(token, 'your_secret_key', algorithms=['HS256'])

        # Retrieve the student and teacher IDs from the payload
        student_id = payload.get('student_id')
        teacher_id = payload.get('teacher_id')

        # Check if the certificate is valid (you can add additional checks)
        if datetime.utcnow() <= datetime.fromtimestamp(payload['exp']):
            student = Student.objects.get(pk=student_id)
            teacher = Teacher.objects.get(pk=teacher_id)

            # Return a JSON response with the certificate details
            certificate_details = {
                'student_name': student.name,
                'teacher_name': teacher.name,
                'certificate_valid': True
            }
            return JsonResponse(certificate_details)

    except jwt.ExpiredSignatureError:
        # Handle expired tokens
        return HttpResponse('Certificate has expired.', status=403)

    except (jwt.DecodeError, Student.DoesNotExist, Teacher.DoesNotExist):
        # Handle invalid tokens or missing data
        return HttpResponse('Invalid certificate token.', status=400)

    # Handle any other errors
    return HttpResponse('Certificate verification failed.', status=500)

#Make sure to replace 'your_secret_key' with your actual secret key.

#Create a URL pattern in your app's urls.py to map the verify_certificate view:
from django.urls import path
from . import views

urlpatterns = [
    # Your existing views
    # ...
    path('verify_certificate/<str:token>/', views.verify_certificate, name='verify_certificate'),
]

"""You can now access the verify_certificate view by providing a valid token as part of the URL, like /verify_certificate/<token>.
This view will verify the certificate and return certificate details if it's valid."""
