#Level 1

""" There is many to many relationships between students and teachers.Store their data in the tables.
if a teacher is selected the corresponding students will be displayed and
if the students are selected then the corresponding teachers should be displayed"""

#Create a new Django project and app
django-admin startproject myproject
cd myproject
python manage.py startapp myapp

#Define your models in models.py of your app (e.g., myapp/models.py):
from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=255)
    age = models.IntegerField()

    def __str__(self):
        return self.name

class Teacher(models.Model):
    name = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class StudentTeacher(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.student} - {self.teacher}"

#Create and apply migrations to create the database tables:
python manage.py makemigrations
python manage.py migrate

"""Now, you can use the Django admin site to add students and teachers and create many-to-many relationships between them.
    To do so, register these models in the admin.py file (e.g., myapp/admin.py):"""

from django.contrib import admin
from .models import Student, Teacher, StudentTeacher

admin.site.register(Student)
admin.site.register(Teacher)
admin.site.register(StudentTeacher)

"""Create views and templates to display students for a selected teacher and teachers for a selected student.
For example, create a view in views.py (e.g., myapp/views.py) and corresponding templates:"""

from django.shortcuts import render
from .models import Student, Teacher, StudentTeacher

def students_for_teacher(request, teacher_id):
    teacher = Teacher.objects.get(pk=teacher_id)
    students = Student.objects.filter(studentteacher__teacher=teacher)
    return render(request, 'students_for_teacher.html', {'teacher': teacher, 'students': students})

def teachers_for_student(request, student_id):
    student = Student.objects.get(pk=student_id)
    teachers = Teacher.objects.filter(studentteacher__student=student)
    return render(request, 'teachers_for_student.html', {'student': student, 'teachers': teachers})

"""Create corresponding HTML templates (students_for_teacher.html and teachers_for_student.html) to display the data."""

#Create URLs for these views in your app's urls.py (e.g., myapp/urls.py):
from django.urls import path
from . import views

urlpatterns = [
    path('students_for_teacher/<int:teacher_id>/', views.students_for_teacher, name='students_for_teacher'),
    path('teachers_for_student/<int:student_id>/', views.teachers_for_student, name='teachers_for_student'),
]

#Finally, include these URLs in your project's urls.py:
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('myapp/', include('myapp.urls')),
]
"""Now, you can access the views you created to display students for a selected teacher and teachers for a selected student.
Make sure to configure your project's settings, including the INSTALLED_APPS, database settings, and static files, as per your project requirements."""


